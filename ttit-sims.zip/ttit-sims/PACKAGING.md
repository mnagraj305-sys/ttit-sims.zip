# Layer 4 – Android Release Packaging

## 1. Generate the release keystore

```bash
keytool -genkey -v \
  -keystore ~/ttit-upload-keystore.jks \
  -storetype JKS \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias ttit_upload
```

Windows PowerShell: use `$env:USERPROFILE\ttit-upload-keystore.jks` as the path.
Back the `.jks` file and both passwords up somewhere safe. If you lose them you cannot update the app on Play Store (unless you use Play App Signing).

## 2. `android/key.properties`

```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=ttit_upload
storeFile=/home/youruser/ttit-upload-keystore.jks
```

This file must never be committed (see `.gitignore` below).

## 3. `android/app/build.gradle` modification matrix

| Location in file | Change |
|---|---|
| Top of file (above `android {}`) | Load `key.properties` |
| `android { signingConfigs { } }` | Add `release` config reading the properties |
| `android { buildTypes { release { } } }` | Point `signingConfig` at `signingConfigs.release`; enable shrinking |

**Groovy (`build.gradle`)**

```groovy
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    // ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

**Kotlin DSL (`build.gradle.kts`, newer Flutter templates)**

```kotlin
import java.util.Properties
import java.io.FileInputStream

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
        }
    }
}
```

## 4. Other Android requirements for this app

- `AndroidManifest.xml`: add `<uses-permission android:name="android.permission.INTERNET"/>` and `<uses-permission android:name="android.permission.USE_BIOMETRIC"/>`.
- `MainActivity.kt` must extend `FlutterFragmentActivity` (required by `local_auth`).
- For an HTTP (non-TLS) dev server add `android:usesCleartextTraffic="true"` to `<application>`. Use HTTPS in production and remove it.
- Minimum SDK 21 or higher (`minSdkVersion` in `build.gradle`).

## 5. Build commands

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://api.your-domain.in
flutter build appbundle --release --dart-define=API_BASE_URL=https://api.your-domain.in   # for Play Store
```

## 6. Production `.gitignore`

```gitignore
# Secrets & environment
.env
.env.*
!.env.example
*.pem
*.key
*.jks
*.keystore
key.properties
**/android/key.properties
firebase-service-account*.json
google-services.json
GoogleService-Info.plist

# Backups & logs
*.sql
*.sql.gz
*.log

# Node
node_modules/
npm-debug.log*

# Flutter / Dart build artifacts
.dart_tool/
.flutter-plugins
.flutter-plugins-dependencies
.packages
.pub-cache/
.pub/
build/
**/android/.gradle/
**/android/local.properties
**/android/app/release/
**/android/app/debug/
**/ios/Pods/
**/ios/.symlinks/
*.apk
*.aab
*.ipa

# IDE / OS
.idea/
*.iml
.vscode/
.DS_Store
```

Note: `*.sql` also ignores `database/schema.sql`. If you want it tracked, add `!database/schema.sql` after that line.

## 7. Backend deployment notes (Ubuntu)

```bash
cd backend && npm install && cp .env.example .env     # edit secrets
psql -U postgres -c "CREATE DATABASE ttit_sims;"
psql -U postgres -d ttit_sims -f ../database/schema.sql
node server.js                                         # use pm2/systemd + nginx with HTTPS in production
sudo ../ops/backup.sh --install                        # daily 02:00 AM backup cron
```
