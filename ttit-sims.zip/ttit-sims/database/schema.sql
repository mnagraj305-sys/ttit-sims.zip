-- Dr. TTIT Student Information & Attendance Management System
-- Run: psql -U postgres -d ttit_sims -f schema.sql
BEGIN;

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  usn           VARCHAR(20)  NOT NULL UNIQUE CHECK (usn = UPPER(usn)),
  name          VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(10)  NOT NULL CHECK (role IN ('student','faculty','admin')),
  branch        VARCHAR(50),
  semester      SMALLINT CHECK (semester BETWEEN 1 AND 8),
  fcm_token     VARCHAR(255)
);
CREATE INDEX IF NOT EXISTS idx_users_branch_sem ON users (branch, semester, role);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_fcm ON users (fcm_token) WHERE fcm_token IS NOT NULL;

CREATE TABLE IF NOT EXISTS attendance (
  id           SERIAL PRIMARY KEY,
  usn          VARCHAR(20)  NOT NULL REFERENCES users(usn) ON DELETE CASCADE ON UPDATE CASCADE,
  subject_name VARCHAR(100) NOT NULL,
  date         DATE NOT NULL DEFAULT CURRENT_DATE,
  status       VARCHAR(10)  NOT NULL CHECK (status IN ('Present','Absent')),
  CONSTRAINT uq_attendance_day UNIQUE (usn, subject_name, date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_usn ON attendance (usn);

CREATE TABLE IF NOT EXISTS internal_marks (
  id           SERIAL PRIMARY KEY,
  usn          VARCHAR(20)  NOT NULL REFERENCES users(usn) ON DELETE CASCADE ON UPDATE CASCADE,
  subject_name VARCHAR(100) NOT NULL,
  ia_1         SMALLINT NOT NULL DEFAULT 0 CHECK (ia_1 BETWEEN 0 AND 40),
  ia_2         SMALLINT NOT NULL DEFAULT 0 CHECK (ia_2 BETWEEN 0 AND 40),
  ia_3         SMALLINT NOT NULL DEFAULT 0 CHECK (ia_3 BETWEEN 0 AND 40),
  assignment   SMALLINT NOT NULL DEFAULT 0 CHECK (assignment BETWEEN 0 AND 10)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_internal_usn_subject ON internal_marks (usn, subject_name);

CREATE TABLE IF NOT EXISTS timetables (
  id           SERIAL PRIMARY KEY,
  branch       VARCHAR(50)  NOT NULL,
  semester     SMALLINT     NOT NULL CHECK (semester BETWEEN 1 AND 8),
  day_of_week  VARCHAR(10)  NOT NULL CHECK (day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday')),
  slot_time    VARCHAR(30)  NOT NULL,           -- e.g. '09:00 AM - 10:00 AM'
  subject_name VARCHAR(100) NOT NULL,
  room_number  VARCHAR(20)
);
CREATE INDEX IF NOT EXISTS idx_timetable_lookup ON timetables (branch, semester);

CREATE TABLE IF NOT EXISTS fee_structures (
  id                SERIAL PRIMARY KEY,
  usn               VARCHAR(20) NOT NULL REFERENCES users(usn) ON DELETE CASCADE ON UPDATE CASCADE,
  total_tuition_fee NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (total_tuition_fee >= 0),
  bus_fee           NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (bus_fee >= 0),
  amount_paid       NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (amount_paid >= 0),
  due_date          DATE,
  payment_status    VARCHAR(10) NOT NULL DEFAULT 'Pending' CHECK (payment_status IN ('Paid','Partial','Pending'))
);
CREATE INDEX IF NOT EXISTS idx_fees_usn ON fee_structures (usn);

CREATE TABLE IF NOT EXISTS exam_results (
  id             SERIAL PRIMARY KEY,
  usn            VARCHAR(20)  NOT NULL REFERENCES users(usn) ON DELETE CASCADE ON UPDATE CASCADE,
  subject_code   VARCHAR(20)  NOT NULL,
  subject_name   VARCHAR(100) NOT NULL,
  internal_marks SMALLINT NOT NULL CHECK (internal_marks BETWEEN 0 AND 50),
  external_marks SMALLINT NOT NULL CHECK (external_marks BETWEEN 0 AND 50),
  grade          VARCHAR(3),
  gpa            NUMERIC(4,2) CHECK (gpa BETWEEN 0 AND 10),
  semester       SMALLINT NOT NULL CHECK (semester BETWEEN 1 AND 8),
  CONSTRAINT uq_result UNIQUE (usn, subject_code, semester)
);

COMMIT;
