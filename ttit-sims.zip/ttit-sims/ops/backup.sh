#!/usr/bin/env bash
# Dr. TTIT SIMS - daily PostgreSQL backup (Ubuntu)
# Usage:  ./backup.sh            -> run a backup now
#         ./backup.sh --install  -> register daily 02:00 AM cron job
set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-/var/backups/ttit_sims}"
LOG_FILE="${LOG_FILE:-/var/log/ttit_sims_backup.log}"
RETENTION_DAYS=30
ENV_FILE="${ENV_FILE:-/opt/ttit-sims/backend/.env}"
SCRIPT_PATH="$(readlink -f "$0")"

if [[ "${1:-}" == "--install" ]]; then
  CRON_LINE="0 2 * * * ${SCRIPT_PATH} >> ${LOG_FILE} 2>&1"
  ( crontab -l 2>/dev/null | grep -vF "${SCRIPT_PATH}" || true; echo "${CRON_LINE}" ) | crontab -
  echo "Cron installed: ${CRON_LINE}"
  exit 0
fi

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# DATABASE_URL is read from the backend .env (value only, no shell evaluation)
DATABASE_URL="$(grep -E '^DATABASE_URL=' "${ENV_FILE}" | head -n1 | cut -d= -f2-)"
[[ -n "${DATABASE_URL}" ]] || { log "ERROR: DATABASE_URL not found in ${ENV_FILE}"; exit 1; }

mkdir -p "${BACKUP_DIR}"
STAMP="$(date '+%Y%m%d_%H%M%S')"
TARGET="${BACKUP_DIR}/ttit_sims_${STAMP}.sql.gz"
START=$(date +%s)

log "Backup started -> ${TARGET}"
if pg_dump "${DATABASE_URL}" | gzip -9 > "${TARGET}.partial"; then
  mv "${TARGET}.partial" "${TARGET}"
  SIZE=$(du -h "${TARGET}" | cut -f1)
  log "Backup OK: size=${SIZE}, duration=$(( $(date +%s) - START ))s"
else
  rm -f "${TARGET}.partial"
  log "ERROR: pg_dump failed"
  exit 1
fi

DELETED=$(find "${BACKUP_DIR}" -name 'ttit_sims_*.sql.gz' -type f -mtime +${RETENTION_DAYS} -print -delete | wc -l)
log "Retention: removed ${DELETED} file(s) older than ${RETENTION_DAYS} days"
