'use strict';
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const PDFDocument = require('pdfkit');
const admin = require('firebase-admin');

// ───────────────────────────── Config ─────────────────────────────
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
const SALT_ROUNDS = 10;
const DEFAULT_PASSWORD = 'Welcome@DrTTIT';
const VTU_THRESHOLD = 75;
const ROLES = ['student', 'faculty', 'admin'];

if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET is not set.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
});
pool.on('error', (err) => console.error('Unexpected PG pool error:', err.message));

let pushEnabled = false;
try {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH) {
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const serviceAccount = require(require('path').resolve(process.env.FIREBASE_SERVICE_ACCOUNT_PATH));
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    pushEnabled = true;
  } else {
    console.warn('Firebase not configured: push notifications disabled.');
  }
} catch (err) {
  console.error('Firebase init failed, push disabled:', err.message);
}

// ───────────────────────────── Helpers ─────────────────────────────
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const normUsn = (v) => String(v || '').trim().toUpperCase();
const isStr = (v, max = 100) => typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max;
const isIntIn = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
const isIsoDate = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));
const round2 = (n) => Math.round(n * 100) / 100;
const need = (cond, msg) => {
  if (!cond) throw new HttpError(400, msg);
};

// ───────────────────────────── Auth middleware ─────────────────────────────
function verifyHeader(req) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function authenticate(req, res, next) {
  const payload = verifyHeader(req);
  if (!payload) return res.status(401).json({ error: 'Invalid or expired token' });
  req.user = payload;
  return next();
}
const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'Insufficient permissions' });

// Students may only read their own records; staff may read anyone's.
function selfOrStaff(req, res, next) {
  const usn = normUsn(req.params.usn);
  if (req.user.role === 'student' && req.user.usn !== usn) {
    return res.status(403).json({ error: 'You can only access your own records' });
  }
  req.params.usn = usn;
  return next();
}

// ───────────────────────────── App ─────────────────────────────
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false }));

// ── Health ──
app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'up', uptime_s: Math.round(process.uptime()) });
  } catch (err) {
    res.status(503).json({ status: 'error', database: 'down' });
  }
});

// ── Auth ──
app.post('/api/auth/register', ah(async (req, res) => {
  const { usn, name, password, role = 'student', branch = null, semester = null } = req.body || {};
  need(isStr(usn, 20), 'usn is required (max 20 chars)');
  need(isStr(name), 'name is required');
  need(typeof password === 'string' && password.length >= 8, 'password must be at least 8 characters');
  need(ROLES.includes(role), `role must be one of ${ROLES.join(', ')}`);
  need(semester === null || isIntIn(semester, 1, 8), 'semester must be 1-8');

  // Only an authenticated admin may create faculty/admin accounts.
  if (role !== 'student') {
    const caller = verifyHeader(req);
    if (!caller || caller.role !== 'admin') throw new HttpError(403, 'Only admins can create faculty/admin accounts');
  }

  const hash = await bcrypt.hash(password, SALT_ROUNDS);
  const { rows } = await pool.query(
    `INSERT INTO users (usn, name, password_hash, role, branch, semester)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, usn, name, role, branch, semester`,
    [normUsn(usn), name.trim(), hash, role, branch, semester],
  );
  res.status(201).json({ user: rows[0] });
}));

app.post('/api/auth/login', ah(async (req, res) => {
  const { usn, password } = req.body || {};
  need(isStr(usn, 20) && typeof password === 'string' && password.length > 0, 'usn and password are required');

  const { rows } = await pool.query('SELECT * FROM users WHERE usn = $1', [normUsn(usn)]);
  const u = rows[0];
  const ok = u && (await bcrypt.compare(password, u.password_hash));
  if (!ok) throw new HttpError(401, 'Invalid USN or password');

  const token = jwt.sign({ id: u.id, usn: u.usn, role: u.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({
    token,
    user: { id: u.id, usn: u.usn, name: u.name, role: u.role, branch: u.branch, semester: u.semester },
  });
}));

app.post('/api/auth/update-fcm', authenticate, ah(async (req, res) => {
  const { fcm_token: token } = req.body || {};
  need(isStr(token, 255), 'fcm_token is required');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // A device token belongs to exactly one account.
    await client.query('UPDATE users SET fcm_token = NULL WHERE fcm_token = $1 AND usn <> $2', [token, req.user.usn]);
    await client.query('UPDATE users SET fcm_token = $1 WHERE usn = $2', [token, req.user.usn]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
  res.json({ message: 'FCM token saved' });
}));

// ── Students list (used by faculty attendance screen) ──
app.get('/api/students/:branch/:semester', authenticate, requireRole('faculty', 'admin'), ah(async (req, res) => {
  const semester = Number(req.params.semester);
  need(isIntIn(semester, 1, 8), 'semester must be 1-8');
  const { rows } = await pool.query(
    `SELECT usn, name FROM users WHERE role='student' AND LOWER(branch)=LOWER($1) AND semester=$2 ORDER BY usn`,
    [req.params.branch, semester],
  );
  res.json({ students: rows });
}));

// ── Attendance ──
app.get('/api/attendance/summary/:usn', authenticate, selfOrStaff, ah(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT subject_name,
            COUNT(*)::int AS total,
            COUNT(*) FILTER (WHERE status = 'Present')::int AS attended
       FROM attendance WHERE usn = $1
      GROUP BY subject_name ORDER BY subject_name`,
    [req.params.usn],
  );
  const subjects = rows.map((r) => ({ ...r, percentage: r.total ? round2((r.attended / r.total) * 100) : 0 }));
  const total = rows.reduce((s, r) => s + r.total, 0);
  const attended = rows.reduce((s, r) => s + r.attended, 0);
  res.json({
    usn: req.params.usn,
    subjects,
    overall_percentage: total ? round2((attended / total) * 100) : 0,
  });
}));

async function notifyLowAttendance(usns) {
  const result = { checked: usns.length, below_threshold: 0, notified: 0 };
  if (!usns.length) return result;
  const { rows } = await pool.query(
    `SELECT u.usn, u.name, u.fcm_token,
            (COUNT(*) FILTER (WHERE a.status='Present')::float / NULLIF(COUNT(*),0) * 100) AS pct
       FROM users u JOIN attendance a ON a.usn = u.usn
      WHERE u.usn = ANY($1::text[])
      GROUP BY u.usn, u.name, u.fcm_token`,
    [usns],
  );
  for (const s of rows) {
    const pct = Number(s.pct);
    if (pct >= VTU_THRESHOLD) continue;
    result.below_threshold += 1;
    if (!pushEnabled || !s.fcm_token) continue;
    try {
      await admin.messaging().send({
        token: s.fcm_token,
        notification: {
          title: 'Low Attendance Alert',
          body: `Hi ${s.name}, your attendance is ${pct.toFixed(1)}%, below the VTU ${VTU_THRESHOLD}% requirement.`,
        },
        data: { type: 'low_attendance', percentage: pct.toFixed(2) },
      });
      result.notified += 1;
    } catch (err) {
      console.error(`FCM failed for ${s.usn}:`, err.code || err.message);
      if (err.code === 'messaging/registration-token-not-registered') {
        await pool.query('UPDATE users SET fcm_token = NULL WHERE usn = $1', [s.usn]).catch(() => {});
      }
    }
  }
  return result;
}

app.post('/api/attendance/mark', authenticate, requireRole('faculty'), ah(async (req, res) => {
  const { subject_name: subject, date = null, records } = req.body || {};
  need(isStr(subject), 'subject_name is required');
  need(date === null || isIsoDate(date), 'date must be YYYY-MM-DD');
  need(Array.isArray(records) && records.length > 0 && records.length <= 500, 'records must be a non-empty array (max 500)');
  const clean = records.map((r) => {
    need(r && isStr(r.usn, 20) && ['Present', 'Absent'].includes(r.status), 'each record needs usn and status (Present|Absent)');
    return { usn: normUsn(r.usn), status: r.status };
  });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const r of clean) {
      await client.query(
        `INSERT INTO attendance (usn, subject_name, date, status)
         VALUES ($1, $2, COALESCE($3::date, CURRENT_DATE), $4)
         ON CONFLICT (usn, subject_name, date) DO UPDATE SET status = EXCLUDED.status`,
        [r.usn, subject.trim(), date, r.status],
      );
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  // Post-commit: VTU 75% check + push alerts. Failures here never undo the saved sheet.
  let alerts = { checked: 0, below_threshold: 0, notified: 0 };
  try {
    alerts = await notifyLowAttendance([...new Set(clean.map((r) => r.usn))]);
  } catch (err) {
    console.error('Post-commit alert pass failed:', err.message);
  }
  res.status(201).json({ message: 'Attendance saved', saved: clean.length, alerts });
}));

// ── Internals ──
app.post('/api/internals/submit', authenticate, requireRole('faculty'), ah(async (req, res) => {
  const body = req.body || {};
  const items = Array.isArray(body.records) ? body.records : [body];
  need(items.length > 0 && items.length <= 500, 'Provide 1-500 records');
  items.forEach((m) => {
    need(isStr(m.usn, 20) && isStr(m.subject_name), 'usn and subject_name are required');
    need(['ia_1', 'ia_2', 'ia_3'].every((k) => isIntIn(m[k], 0, 40)), 'ia_1, ia_2, ia_3 must be integers 0-40');
    need(isIntIn(m.assignment, 0, 10), 'assignment must be an integer 0-10');
  });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const m of items) {
      await client.query(
        `INSERT INTO internal_marks (usn, subject_name, ia_1, ia_2, ia_3, assignment)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (usn, subject_name) DO UPDATE
           SET ia_1=EXCLUDED.ia_1, ia_2=EXCLUDED.ia_2, ia_3=EXCLUDED.ia_3, assignment=EXCLUDED.assignment`,
        [normUsn(m.usn), m.subject_name.trim(), m.ia_1, m.ia_2, m.ia_3, m.assignment],
      );
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
  res.status(201).json({ message: 'Internal marks saved', saved: items.length });
}));

// VTU CIE: average of the best two IAs (max 40) + assignment (max 10) = 50
const finalCie = (m) => {
  const best2 = [m.ia_1, m.ia_2, m.ia_3].sort((a, b) => b - a).slice(0, 2);
  return round2((best2[0] + best2[1]) / 2 + m.assignment);
};

app.get('/api/internals/summary/:usn', authenticate, selfOrStaff, ah(async (req, res) => {
  const { rows } = await pool.query(
    'SELECT subject_name, ia_1, ia_2, ia_3, assignment FROM internal_marks WHERE usn=$1 ORDER BY subject_name',
    [req.params.usn],
  );
  res.json({ usn: req.params.usn, internals: rows.map((r) => ({ ...r, final_cie: finalCie(r) })) });
}));

// ── Timetable ──
app.get('/api/timetable/:branch/:semester', authenticate, ah(async (req, res) => {
  const semester = Number(req.params.semester);
  need(isIntIn(semester, 1, 8), 'semester must be 1-8');
  const { rows } = await pool.query(
    `SELECT day_of_week, slot_time, subject_name, room_number
       FROM timetables
      WHERE LOWER(branch) = LOWER($1) AND semester = $2
      ORDER BY array_position(ARRAY['Monday','Tuesday','Wednesday','Thursday','Friday'], day_of_week),
               to_timestamp(split_part(slot_time, ' - ', 1), 'HH12:MI AM')::time`,
    [req.params.branch, semester],
  );
  res.json({ timetable: rows });
}));

// ── Admin batch registration ──
app.post('/api/admin/batch-students', authenticate, requireRole('admin', 'faculty'), ah(async (req, res) => {
  const { students } = req.body || {};
  need(Array.isArray(students) && students.length > 0 && students.length <= 1000, 'students must be a non-empty array (max 1000)');
  students.forEach((s, i) => {
    need(s && isStr(s.usn, 20) && isStr(s.name), `students[${i}] needs usn and name`);
    need(s.semester === undefined || s.semester === null || isIntIn(s.semester, 1, 8), `students[${i}].semester must be 1-8`);
  });

  const hash = await bcrypt.hash(DEFAULT_PASSWORD, SALT_ROUNDS); // same default for all; users should change it
  const client = await pool.connect();
  let inserted = 0;
  const skipped = [];
  try {
    await client.query('BEGIN');
    for (const s of students) {
      const r = await client.query(
        `INSERT INTO users (usn, name, password_hash, role, branch, semester)
         VALUES ($1,$2,$3,'student',$4,$5) ON CONFLICT (usn) DO NOTHING`,
        [normUsn(s.usn), s.name.trim(), hash, s.branch || null, s.semester || null],
      );
      if (r.rowCount === 1) inserted += 1;
      else skipped.push(normUsn(s.usn));
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
  res.status(201).json({ message: 'Batch complete', inserted, skipped_existing: skipped });
}));

// ── Fees ──
app.get('/api/fees/summary/:usn', authenticate, selfOrStaff, ah(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT total_tuition_fee, bus_fee, amount_paid, due_date, payment_status,
            (total_tuition_fee + bus_fee - amount_paid) AS balance
       FROM fee_structures WHERE usn=$1 ORDER BY due_date NULLS LAST, id`,
    [req.params.usn],
  );
  const sum = (k) => round2(rows.reduce((s, r) => s + Number(r[k]), 0));
  res.json({
    usn: req.params.usn,
    ledger: rows,
    totals: { tuition: sum('total_tuition_fee'), bus: sum('bus_fee'), paid: sum('amount_paid'), balance: sum('balance') },
  });
}));

// ── Grade card PDF ──
app.get('/api/results/pdf/:usn/:semester', authenticate, selfOrStaff, ah(async (req, res) => {
  const semester = Number(req.params.semester);
  need(isIntIn(semester, 1, 8), 'semester must be 1-8');

  const [{ rows: users }, { rows: results }] = await Promise.all([
    pool.query('SELECT usn, name, branch FROM users WHERE usn=$1', [req.params.usn]),
    pool.query(
      `SELECT subject_code, subject_name, internal_marks, external_marks, grade, gpa
         FROM exam_results WHERE usn=$1 AND semester=$2 ORDER BY subject_code`,
      [req.params.usn, semester],
    ),
  ]);
  if (!users[0]) throw new HttpError(404, 'Student not found');
  if (!results.length) throw new HttpError(404, 'No results published for this semester');

  // SGPA = mean of subject GPAs (schema stores no credit weights; add a credits column to weight it)
  const sgpa = results.reduce((s, r) => s + Number(r.gpa || 0), 0) / results.length;

  const doc = new PDFDocument({ size: 'A4', margin: 40, info: { Title: `Grade Card ${users[0].usn} Sem ${semester}` } });
  const chunks = [];
  doc.on('data', (c) => chunks.push(c));
  const done = new Promise((resolve, reject) => {
    doc.on('end', resolve);
    doc.on('error', reject);
  });

  const L = 40;
  const W = 515;
  doc.rect(L, 40, W, 70).fill('#1a237e');
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(16)
    .text('Dr. T. THIMMAIAH INSTITUTE OF TECHNOLOGY', L, 54, { width: W, align: 'center' });
  doc.font('Helvetica').fontSize(10)
    .text('Kolar Gold Fields  |  Affiliated to Visvesvaraya Technological University', L, 76, { width: W, align: 'center' });
  doc.font('Helvetica-Bold').fontSize(12).text('STATEMENT OF GRADES', L, 92, { width: W, align: 'center' });

  doc.fillColor('#000000').font('Helvetica').fontSize(11);
  doc.text(`Name: ${users[0].name}`, L, 130);
  doc.text(`USN: ${users[0].usn}`, L, 148);
  doc.text(`Branch: ${users[0].branch || '-'}`, 330, 130);
  doc.text(`Semester: ${semester}`, 330, 148);

  const cols = [
    { h: 'Code', w: 70 }, { h: 'Subject', w: 185 }, { h: 'Internal', w: 50 },
    { h: 'External', w: 50 }, { h: 'Total', w: 50 }, { h: 'Grade', w: 50 }, { h: 'GPA', w: 60 },
  ];
  const ROW = 24;
  const drawRow = (y, cells, header = false) => {
    let x = L;
    if (header) doc.rect(L, y, W, ROW).fill('#e8eaf6');
    doc.fillColor('#000000').font(header ? 'Helvetica-Bold' : 'Helvetica').fontSize(9.5);
    cols.forEach((c, i) => {
      doc.rect(x, y, c.w, ROW).stroke('#9e9e9e');
      doc.fillColor('#000000').text(String(cells[i] ?? ''), x + 4, y + 8, { width: c.w - 8, height: ROW - 8, lineBreak: false, ellipsis: true });
      x += c.w;
    });
  };

  let y = 185;
  drawRow(y, cols.map((c) => c.h), true);
  y += ROW;
  results.forEach((r) => {
    if (y + ROW > 760) {
      doc.addPage();
      y = 40;
      drawRow(y, cols.map((c) => c.h), true);
      y += ROW;
    }
    drawRow(y, [r.subject_code, r.subject_name, r.internal_marks, r.external_marks,
      r.internal_marks + r.external_marks, r.grade || '-', Number(r.gpa || 0).toFixed(2)]);
    y += ROW;
  });

  y += 20;
  if (y > 740) { doc.addPage(); y = 40; }
  doc.rect(L, y, W, 34).fill('#1a237e');
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(13)
    .text(`SGPA: ${sgpa.toFixed(2)}`, L, y + 10, { width: W, align: 'center' });
  doc.fillColor('#616161').font('Helvetica-Oblique').fontSize(8)
    .text(`Computer generated on ${new Date().toISOString().slice(0, 10)}. Not valid without institutional seal.`, L, y + 50, { width: W, align: 'center' });
  doc.end();
  await done;

  const buffer = Buffer.concat(chunks);
  res.set({
    'Content-Type': 'application/pdf',
    'Content-Length': buffer.length,
    'Content-Disposition': `attachment; filename="GradeCard_${users[0].usn}_Sem${semester}.pdf"`,
  });
  res.send(buffer);
}));

// ───────────────────────────── Errors ─────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const pgMap = { '23505': [409, 'Record already exists'], '23503': [400, 'Referenced USN does not exist'],
    '23514': [400, 'A value is outside the allowed range'], '22P02': [400, 'Malformed value'],
    '22007': [400, 'Invalid date/time value'], '22008': [400, 'Invalid date/time value'] };
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body' });
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (pgMap[err.code]) return res.status(pgMap[err.code][0]).json({ error: pgMap[err.code][1] });
  console.error(err);
  return res.status(500).json({ error: 'Internal server error' });
});

if (require.main === module) {
  const server = app.listen(PORT, () => console.log(`Dr. TTIT SIMS API listening on :${PORT}`));
  const shutdown = () => server.close(() => pool.end().then(() => process.exit(0)));
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

module.exports = app;
