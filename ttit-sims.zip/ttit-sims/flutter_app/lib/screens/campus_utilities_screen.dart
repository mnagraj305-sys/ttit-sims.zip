import 'package:flutter/material.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

class CampusUtilitiesScreen extends StatefulWidget {
  const CampusUtilitiesScreen({super.key});

  @override
  State<CampusUtilitiesScreen> createState() => _CampusUtilitiesScreenState();
}

class _CampusUtilitiesScreenState extends State<CampusUtilitiesScreen> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = ApiService.instance.feeSummary();
  }

  String _money(dynamic v) => '₹${(v as num).toStringAsFixed(2)}';

  Widget _balanceCard(String title, String value, IconData icon, Color color) => Card(
        child: ListTile(
          leading: CircleAvatar(backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color)),
          title: Text(title),
          trailing: Text(value, style: Theme.of(context).textTheme.titleMedium),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Campus Utilities')),
      drawer: const StudentNavigationDrawer(current: 'Campus Utilities'),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Fees & Transit', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              if (snap.connectionState != ConnectionState.done)
                const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))
              else if (snap.hasError)
                Text('${snap.error}')
              else ...[
                _balanceCard('Tuition Fee', _money(snap.data!['totals']['tuition']), Icons.school, Colors.indigo),
                _balanceCard('Transit (Bus) Fee', _money(snap.data!['totals']['bus']), Icons.directions_bus, Colors.orange),
                _balanceCard('Amount Paid', _money(snap.data!['totals']['paid']), Icons.check_circle, Colors.green),
                _balanceCard(
                  'Balance Due',
                  _money(snap.data!['totals']['balance']),
                  Icons.account_balance_wallet,
                  (snap.data!['totals']['balance'] as num) > 0 ? Colors.red : Colors.green,
                ),
              ],
              const SizedBox(height: 24),
              Text('Live Bus Tracking', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Card(
                child: Container(
                  height: 180,
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.map, size: 56, color: Colors.grey),
                      const SizedBox(height: 8),
                      const Text('Real-time tracking placeholder'),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        icon: const Icon(Icons.location_on),
                        label: const Text('View Map'),
                        onPressed: () => showDialog<void>(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('Bus Tracking'),
                            content: const Text('Map integration (e.g. Google Maps) will be connected here.'),
                            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
