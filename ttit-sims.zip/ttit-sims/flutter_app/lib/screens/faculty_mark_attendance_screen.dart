import 'package:flutter/material.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

class FacultyMarkAttendanceScreen extends StatefulWidget {
  const FacultyMarkAttendanceScreen({super.key});

  @override
  State<FacultyMarkAttendanceScreen> createState() => _FacultyMarkAttendanceScreenState();
}

class _FacultyMarkAttendanceScreenState extends State<FacultyMarkAttendanceScreen> {
  static const _branches = ['CSE', 'ISE', 'ECE', 'EEE', 'ME', 'CV'];
  final _subject = TextEditingController();
  String _branch = _branches.first;
  int _semester = 1;
  List<Map<String, dynamic>> _students = [];
  final Map<String, bool> _present = {};
  bool _loading = false;
  bool _submitting = false;

  @override
  void dispose() {
    _subject.dispose();
    super.dispose();
  }

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.instance.students(_branch, _semester);
      setState(() {
        _students = list.cast<Map<String, dynamic>>();
        _present
          ..clear()
          ..addEntries(_students.map((s) => MapEntry(s['usn'].toString(), false)));
      });
      if (_students.isEmpty) _toast('No students found for $_branch / Sem $_semester');
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _toggleAll() {
    final allPresent = _present.values.every((v) => v);
    setState(() => _present.updateAll((_, __) => !allPresent));
  }

  Future<void> _submit() async {
    if (_subject.text.trim().isEmpty) return _toast('Enter the subject name');
    if (_students.isEmpty) return _toast('Load the student list first');
    setState(() => _submitting = true);
    try {
      final records = _present.entries
          .map((e) => {'usn': e.key, 'status': e.value ? 'Present' : 'Absent'})
          .toList();
      final res = await ApiService.instance.markAttendance(_subject.text.trim(), records);
      final alerts = res['alerts'] as Map<String, dynamic>?;
      _toast('Saved ${res['saved']} records. Low-attendance alerts: ${alerts?['below_threshold'] ?? 0}');
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final presentCount = _present.values.where((v) => v).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Mark Attendance')),
      drawer: const StudentNavigationDrawer(current: 'Mark Attendance'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _branch,
                        decoration: const InputDecoration(labelText: 'Branch', border: OutlineInputBorder()),
                        items: _branches.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
                        onChanged: (v) => setState(() => _branch = v ?? _branch),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: DropdownButtonFormField<int>(
                        value: _semester,
                        decoration: const InputDecoration(labelText: 'Semester', border: OutlineInputBorder()),
                        items: List.generate(8, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))).toList(),
                        onChanged: (v) => setState(() => _semester = v ?? _semester),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _subject,
                  decoration: const InputDecoration(labelText: 'Subject Name', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _loading ? null : _load,
                        icon: _loading
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.download),
                        label: const Text('Load Student List'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    OutlinedButton.icon(
                      onPressed: _students.isEmpty ? null : _toggleAll,
                      icon: const Icon(Icons.done_all),
                      label: const Text('Toggle All Present'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_students.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Present: $presentCount / ${_students.length}'),
              ),
            ),
          Expanded(
            child: ListView.builder(
              itemCount: _students.length,
              itemBuilder: (_, i) {
                final s = _students[i];
                final usn = s['usn'].toString();
                return CheckboxListTile(
                  value: _present[usn] ?? false,
                  title: Text(s['name'].toString()),
                  subtitle: Text(usn),
                  onChanged: (v) => setState(() => _present[usn] = v ?? false),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton.icon(
                  onPressed: (_submitting || _students.isEmpty) ? null : _submit,
                  icon: const Icon(Icons.cloud_upload),
                  label: Text(_submitting ? 'Submitting...' : 'Submit Attendance Sheet'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
