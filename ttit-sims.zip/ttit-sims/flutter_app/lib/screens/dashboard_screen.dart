import 'package:flutter/material.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

/// Single source of truth for the VTU rule: >= 75% is green, otherwise red.
Color attendanceColor(double pct) => pct >= 75 ? Colors.green : Colors.red;

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = ApiService.instance.attendanceSummary();
  }

  Future<void> _refresh() async {
    setState(() => _future = ApiService.instance.attendanceSummary());
    await _future.catchError((_) => <String, dynamic>{});
  }

  @override
  Widget build(BuildContext context) {
    final api = ApiService.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Attendance Tracker')),
      drawer: const StudentNavigationDrawer(current: 'Attendance Tracker'),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<Map<String, dynamic>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                Padding(
                  padding: const EdgeInsets.all(32),
                  child: Center(child: Text('${snap.error}', textAlign: TextAlign.center)),
                ),
              ]);
            }
            final subjects = (snap.data!['subjects'] as List<dynamic>);
            final overall = (snap.data!['overall_percentage'] as num).toDouble();
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text((api.user?['name'] ?? '').toString()),
                    subtitle: Text('${api.usn}\n${api.branch} • Semester ${api.semester}'),
                    isThreeLine: true,
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('${overall.toStringAsFixed(1)}%',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold, color: attendanceColor(overall))),
                        const Text('Overall', style: TextStyle(fontSize: 11)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                if (subjects.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: Text('No attendance recorded yet.')),
                  ),
                ...subjects.map((s) => _SubjectTile(data: s as Map<String, dynamic>)),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SubjectTile extends StatelessWidget {
  final Map<String, dynamic> data;
  const _SubjectTile({required this.data});

  @override
  Widget build(BuildContext context) {
    final pct = (data['percentage'] as num).toDouble();
    final color = attendanceColor(pct);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            SizedBox(
              width: 64,
              height: 64,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox.expand(
                    child: CircularProgressIndicator(
                      value: (pct / 100).clamp(0.0, 1.0),
                      strokeWidth: 7,
                      color: color,
                      backgroundColor: color.withOpacity(0.15),
                    ),
                  ),
                  Text('${pct.toStringAsFixed(0)}%',
                      style: TextStyle(fontWeight: FontWeight.bold, color: color)),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data['subject_name'].toString(), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text('Attended ${data['attended']} of ${data['total']} classes'),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: (pct / 100).clamp(0.0, 1.0),
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4),
                    color: color,
                    backgroundColor: color.withOpacity(0.15),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
