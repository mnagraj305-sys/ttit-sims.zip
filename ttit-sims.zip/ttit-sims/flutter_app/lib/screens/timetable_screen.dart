import 'package:flutter/material.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

class TimetableScreen extends StatefulWidget {
  const TimetableScreen({super.key});

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  static const _days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  late Future<List<dynamic>> _future;
  late String _selected;

  @override
  void initState() {
    super.initState();
    final today = DateTime.now().weekday; // 1=Mon..7=Sun
    _selected = today <= 5 ? _days[today - 1] : _days.first;
    _future = ApiService.instance.timetable();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Class Timetable')),
      drawer: const StudentNavigationDrawer(current: 'Class Timetable'),
      body: Column(
        children: [
          SizedBox(
            height: 56,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: _days
                  .map((d) => Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(d.substring(0, 3)),
                          selected: _selected == d,
                          onSelected: (_) => setState(() => _selected = d),
                        ),
                      ))
                  .toList(),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<dynamic>>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) return Center(child: Text('${snap.error}'));
                final items = snap.data!.where((e) => e['day_of_week'] == _selected).toList();
                if (items.isEmpty) return Center(child: Text('No classes on $_selected'));
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final c = items[i] as Map<String, dynamic>;
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.menu_book),
                        title: Text(c['subject_name'].toString()),
                        subtitle: Text(c['slot_time'].toString()),
                        trailing: Chip(label: Text('Room ${c['room_number'] ?? '-'}')),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
