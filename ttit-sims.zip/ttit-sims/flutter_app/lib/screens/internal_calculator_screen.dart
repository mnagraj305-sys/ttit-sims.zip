import 'package:flutter/material.dart';

import '../widgets/student_navigation_drawer.dart';

class InternalCalculatorScreen extends StatefulWidget {
  const InternalCalculatorScreen({super.key});

  @override
  State<InternalCalculatorScreen> createState() => _InternalCalculatorScreenState();
}

class _InternalCalculatorScreenState extends State<InternalCalculatorScreen> {
  double _ia1 = 0, _ia2 = 0, _ia3 = 0, _assign = 0;

  /// VTU CIE = average of best two IAs (each /40) + assignment (/10) => /50.
  double get _bestTwoAvg {
    final sorted = [_ia1, _ia2, _ia3]..sort((a, b) => b.compareTo(a));
    return (sorted[0] + sorted[1]) / 2;
  }

  double get _finalCie => _bestTwoAvg + _assign;

  Widget _slider(String label, double value, double max, ValueChanged<double> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ${value.round()} / ${max.round()}', style: Theme.of(context).textTheme.titleSmall),
          Slider(
            value: value,
            min: 0,
            max: max,
            divisions: max.round(),
            label: value.round().toString(),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Internal Calculator')),
      drawer: const StudentNavigationDrawer(current: 'Internal Calculator'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _slider('IA-1', _ia1, 40, (v) => setState(() => _ia1 = v)),
          _slider('IA-2', _ia2, 40, (v) => setState(() => _ia2 = v)),
          _slider('IA-3', _ia3, 40, (v) => setState(() => _ia3 = v)),
          _slider('Assignment', _assign, 10, (v) => setState(() => _assign = v)),
          const SizedBox(height: 12),
          Card(
            color: cs.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('Average of best 2 IAs: ${_bestTwoAvg.toStringAsFixed(2)} / 40'),
                  Text('Assignment: ${_assign.round()} / 10'),
                  const Divider(height: 24),
                  Text('Final CIE', style: Theme.of(context).textTheme.titleMedium),
                  Text('${_finalCie.toStringAsFixed(2)} / 50',
                      style: Theme.of(context)
                          .textTheme
                          .displaySmall
                          ?.copyWith(fontWeight: FontWeight.bold, color: cs.primary)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text('VTU rule: Final CIE = average of the best two IA scores + assignment score.',
              style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
