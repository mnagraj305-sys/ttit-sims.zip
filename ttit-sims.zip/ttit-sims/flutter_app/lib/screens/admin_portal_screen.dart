import 'dart:convert';

import 'package:flutter/material.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

class AdminPortalScreen extends StatefulWidget {
  const AdminPortalScreen({super.key});

  @override
  State<AdminPortalScreen> createState() => _AdminPortalScreenState();
}

class _AdminPortalScreenState extends State<AdminPortalScreen> {
  static const _sample = '[\n'
      '  {"usn": "4TT22CS001", "name": "Student One", "branch": "CSE", "semester": 5},\n'
      '  {"usn": "4TT22CS002", "name": "Student Two", "branch": "CSE", "semester": 5}\n'
      ']';

  final _input = TextEditingController();
  String _output = '> Paste a JSON array of students, then tap Execute.\n'
      '> Default password for new accounts: Welcome@DrTTIT';
  bool _busy = false;

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _execute() async {
    final text = _input.text.trim();
    if (text.isEmpty) {
      setState(() => _output = '> ERROR: input is empty.');
      return;
    }
    dynamic parsed;
    try {
      parsed = jsonDecode(text);
    } on FormatException catch (e) {
      setState(() => _output = '> ERROR: invalid JSON - ${e.message}');
      return;
    }
    final list = parsed is Map<String, dynamic> ? parsed['students'] : parsed;
    if (list is! List || list.isEmpty) {
      setState(() => _output = '> ERROR: expected a non-empty JSON array (or {"students": [...]}).');
      return;
    }
    for (var i = 0; i < list.length; i++) {
      final s = list[i];
      if (s is! Map || (s['usn'] ?? '').toString().trim().isEmpty || (s['name'] ?? '').toString().trim().isEmpty) {
        setState(() => _output = '> ERROR: entry #${i + 1} needs "usn" and "name".');
        return;
      }
    }

    setState(() {
      _busy = true;
      _output = '> Sending ${list.length} profiles...';
    });
    try {
      final res = await ApiService.instance.batchStudents(list);
      final skipped = (res['skipped_existing'] as List?) ?? [];
      setState(() => _output = '> OK: inserted ${res['inserted']}, '
          'skipped ${skipped.length} existing${skipped.isEmpty ? '' : ' (${skipped.join(', ')})'}.');
    } on ApiException catch (e) {
      setState(() => _output = '> ERROR: ${e.message}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Portal')),
      drawer: const StudentNavigationDrawer(current: 'Admin Portal'),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              flex: 3,
              child: TextField(
                controller: _input,
                expands: true,
                maxLines: null,
                minLines: null,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Paste batch JSON here',
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _execute,
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Execute Batch'),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () => setState(() => _input.text = _sample),
                  child: const Text('Sample'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Expanded(
              flex: 2,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(8)),
                child: SingleChildScrollView(
                  child: Text(_output,
                      style: const TextStyle(color: Colors.greenAccent, fontFamily: 'monospace', fontSize: 13)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
