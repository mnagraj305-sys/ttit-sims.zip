import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../api_service.dart';
import '../widgets/student_navigation_drawer.dart';

class GradeCardScreen extends StatefulWidget {
  const GradeCardScreen({super.key});

  @override
  State<GradeCardScreen> createState() => _GradeCardScreenState();
}

class _GradeCardScreenState extends State<GradeCardScreen> {
  int _semester = ApiService.instance.semester.clamp(1, 8);
  bool _downloading = false;
  String? _savedPath;

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _download() async {
    setState(() {
      _downloading = true;
      _savedPath = null;
    });
    try {
      final bytes = await ApiService.instance.gradeCardPdf(_semester);
      // App-specific external storage on Android (no runtime permission needed); documents dir elsewhere.
      final dir = (Platform.isAndroid ? await getExternalStorageDirectory() : null) ??
          await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/GradeCard_${ApiService.instance.usn}_Sem$_semester.pdf');
      await file.writeAsBytes(bytes, flush: true);
      if (!mounted) return;
      setState(() => _savedPath = file.path);
      _toast('Grade card saved');
    } on ApiException catch (e) {
      _toast(e.message);
    } on FileSystemException catch (e) {
      _toast('Could not save file: ${e.message}');
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Exam Result Sheets')),
      drawer: const StudentNavigationDrawer(current: 'Exam Result Sheets'),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.description, size: 72),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _semester,
              decoration: const InputDecoration(labelText: 'Select Semester', border: OutlineInputBorder()),
              items: List.generate(8, (i) => DropdownMenuItem(value: i + 1, child: Text('Semester ${i + 1}'))),
              onChanged: (v) => setState(() => _semester = v ?? _semester),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _downloading ? null : _download,
              icon: _downloading
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.download),
              label: Text(_downloading ? 'Downloading...' : 'Download Grade Card (PDF)'),
            ),
            if (_savedPath != null) ...[
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.check_circle, color: Colors.green),
                  title: const Text('Saved to device'),
                  subtitle: SelectableText(_savedPath!),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
