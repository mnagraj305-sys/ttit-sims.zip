import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';

import '../api_service.dart';
import '../main.dart' show homeForRole;

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usn = TextEditingController();
  final _password = TextEditingController();
  final _auth = LocalAuthentication();
  final _api = ApiService.instance;
  bool _loading = false;
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    // On later launches a valid stored token + biometric success skips the form.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_api.hasValidToken) _biometricLogin();
    });
  }

  @override
  void dispose() {
    _usn.dispose();
    _password.dispose();
    super.dispose();
  }

  void _toast(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  void _goHome() => Navigator.of(context)
      .pushReplacement(MaterialPageRoute(builder: (_) => homeForRole()));

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await _api.login(_usn.text, _password.text);
      if (mounted) _goHome();
    } on ApiException catch (e) {
      if (mounted) _toast(e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _biometricLogin() async {
    if (!_api.hasValidToken) {
      _toast('Sign in with your USN and password first.');
      return;
    }
    try {
      final supported = await _auth.isDeviceSupported() && await _auth.canCheckBiometrics;
      if (!supported) {
        _toast('Biometrics not available on this device.');
        return;
      }
      final ok = await _auth.authenticate(
        localizedReason: 'Authenticate to open Dr. TTIT',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (ok && mounted) _goHome();
    } catch (_) {
      if (mounted) _toast('Biometric authentication failed.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.school, size: 72, color: cs.primary),
                    const SizedBox(height: 8),
                    Text('Dr. TTIT', style: Theme.of(context).textTheme.headlineMedium),
                    const Text('Student Information & Attendance'),
                    const SizedBox(height: 32),
                    TextFormField(
                      controller: _usn,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                          labelText: 'USN', prefixIcon: Icon(Icons.badge), border: OutlineInputBorder()),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter your USN' : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _password,
                      obscureText: _obscure,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock),
                        border: const OutlineInputBorder(),
                        suffixIcon: IconButton(
                          icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                      validator: (v) => (v == null || v.isEmpty) ? 'Enter your password' : null,
                      onFieldSubmitted: (_) => _login(),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: FilledButton(
                        onPressed: _loading ? null : _login,
                        child: _loading
                            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text('Sign In'),
                      ),
                    ),
                    const SizedBox(height: 28),
                    IconButton.filledTonal(
                      iconSize: 56,
                      tooltip: 'Sign in with fingerprint / Face ID',
                      icon: const Icon(Icons.fingerprint),
                      onPressed: _biometricLogin,
                    ),
                    const SizedBox(height: 6),
                    const Text('Biometric sign-in', style: TextStyle(fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
