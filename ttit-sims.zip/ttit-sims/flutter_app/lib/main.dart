import 'package:flutter/material.dart';

import 'api_service.dart';
import 'screens/admin_portal_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/faculty_mark_attendance_screen.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ApiService.instance.loadSession();
  runApp(const TtitApp());
}

/// Chooses the landing screen by role.
Widget homeForRole() {
  switch (ApiService.instance.role) {
    case 'faculty':
      return const FacultyMarkAttendanceScreen();
    case 'admin':
      return const AdminPortalScreen();
    default:
      return const DashboardScreen();
  }
}

class TtitApp extends StatelessWidget {
  const TtitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dr. TTIT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1A237E)),
      // LoginScreen offers the biometric shortcut when a valid stored token exists.
      home: const LoginScreen(),
    );
  }
}
