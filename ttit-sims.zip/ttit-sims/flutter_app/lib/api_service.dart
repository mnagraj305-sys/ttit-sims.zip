import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// Singleton network + session wrapper.
class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  static const String baseUrl =
      String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');
  static const _tokenKey = 'auth_token';
  static const _userKey = 'auth_user';
  static const _timeout = Duration(seconds: 25);

  String? token;
  Map<String, dynamic>? user;

  String get role => (user?['role'] ?? '') as String;
  String get usn => (user?['usn'] ?? '') as String;
  String get branch => (user?['branch'] ?? '') as String;
  int get semester => (user?['semester'] ?? 1) as int;

  // ── Session ──
  Future<void> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    token = prefs.getString(_tokenKey);
    final raw = prefs.getString(_userKey);
    user = raw == null ? null : jsonDecode(raw) as Map<String, dynamic>;
  }

  /// Client-side check of the JWT `exp` claim (server remains the authority).
  bool get hasValidToken {
    final t = token;
    if (t == null || user == null) return false;
    try {
      final parts = t.split('.');
      if (parts.length != 3) return false;
      final payload =
          jsonDecode(utf8.decode(base64Url.decode(base64Url.normalize(parts[1])))) as Map<String, dynamic>;
      final exp = payload['exp'] as int?;
      return exp != null && DateTime.fromMillisecondsSinceEpoch(exp * 1000).isAfter(DateTime.now());
    } catch (_) {
      return false;
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
    token = null;
    user = null;
  }

  // ── HTTP plumbing ──
  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<http.Response> _send(Future<http.Response> Function() call) async {
    try {
      return await call().timeout(_timeout);
    } catch (e) {
      throw ApiException('Cannot reach server. Check your connection.');
    }
  }

  Map<String, dynamic> _json(http.Response r) {
    Map<String, dynamic> body = {};
    try {
      if (r.body.isNotEmpty) body = jsonDecode(r.body) as Map<String, dynamic>;
    } catch (_) {}
    if (r.statusCode >= 400) {
      throw ApiException((body['error'] ?? 'Request failed (${r.statusCode})').toString());
    }
    return body;
  }

  Future<Map<String, dynamic>> _get(String path) async =>
      _json(await _send(() => http.get(Uri.parse('$baseUrl$path'), headers: _headers)));

  Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async =>
      _json(await _send(() => http.post(Uri.parse('$baseUrl$path'), headers: _headers, body: jsonEncode(body))));

  // ── Endpoints ──
  Future<void> login(String usn, String password) async {
    final data = await _post('/api/auth/login', {'usn': usn.trim().toUpperCase(), 'password': password});
    token = data['token'] as String;
    user = data['user'] as Map<String, dynamic>;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token!);
    await prefs.setString(_userKey, jsonEncode(user));
  }

  /// Call with the device token once firebase_messaging is wired up.
  Future<void> updateFcmToken(String fcmToken) => _post('/api/auth/update-fcm', {'fcm_token': fcmToken});

  Future<Map<String, dynamic>> attendanceSummary() => _get('/api/attendance/summary/$usn');

  Future<List<dynamic>> timetable() async =>
      (await _get('/api/timetable/${Uri.encodeComponent(branch)}/$semester'))['timetable'] as List<dynamic>;

  Future<List<dynamic>> students(String branch, int semester) async =>
      (await _get('/api/students/${Uri.encodeComponent(branch)}/$semester'))['students'] as List<dynamic>;

  Future<Map<String, dynamic>> markAttendance(String subject, List<Map<String, String>> records) =>
      _post('/api/attendance/mark', {'subject_name': subject, 'records': records});

  Future<Map<String, dynamic>> batchStudents(List<dynamic> students) =>
      _post('/api/admin/batch-students', {'students': students});

  Future<Map<String, dynamic>> feeSummary() => _get('/api/fees/summary/$usn');

  Future<Uint8List> gradeCardPdf(int semester) async {
    final r = await _send(
        () => http.get(Uri.parse('$baseUrl/api/results/pdf/$usn/$semester'), headers: _headers));
    if (r.statusCode >= 400) _json(r); // throws with server message
    return r.bodyBytes;
  }
}
