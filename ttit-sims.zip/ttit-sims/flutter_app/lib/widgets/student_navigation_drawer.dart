import 'package:flutter/material.dart';

import '../api_service.dart';
import '../screens/admin_portal_screen.dart';
import '../screens/campus_utilities_screen.dart';
import '../screens/dashboard_screen.dart';
import '../screens/faculty_mark_attendance_screen.dart';
import '../screens/grade_card_screen.dart';
import '../screens/internal_calculator_screen.dart';
import '../screens/login_screen.dart';
import '../screens/timetable_screen.dart';

class StudentNavigationDrawer extends StatelessWidget {
  /// Title of the screen hosting the drawer, used to highlight the active item.
  final String current;
  const StudentNavigationDrawer({super.key, required this.current});

  void _go(BuildContext context, Widget page) {
    Navigator.of(context).pop(); // close drawer
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => page));
  }

  Future<void> _logout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('You will need to sign in again.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Log Out')),
        ],
      ),
    );
    if (confirm != true) return;
    await ApiService.instance.logout();
    if (!context.mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final api = ApiService.instance;
    final isStudent = api.role == 'student';
    final isFaculty = api.role == 'faculty';
    final isAdmin = api.role == 'admin';

    Widget item(IconData icon, String label, Widget page) => ListTile(
          leading: Icon(icon),
          title: Text(label),
          selected: current == label,
          onTap: () => current == label ? Navigator.pop(context) : _go(context, page),
        );

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text((api.user?['name'] ?? 'User').toString()),
            accountEmail: Text('${api.usn}  •  ${api.role.toUpperCase()}'),
            currentAccountPicture: const CircleAvatar(child: Icon(Icons.person, size: 36)),
          ),
          if (isStudent) ...[
            item(Icons.fact_check, 'Attendance Tracker', const DashboardScreen()),
            item(Icons.calendar_month, 'Class Timetable', const TimetableScreen()),
            item(Icons.calculate, 'Internal Calculator', const InternalCalculatorScreen()),
            item(Icons.description, 'Exam Result Sheets', const GradeCardScreen()),
            item(Icons.account_balance_wallet, 'Campus Utilities', const CampusUtilitiesScreen()),
          ],
          if (isFaculty) item(Icons.how_to_reg, 'Mark Attendance', const FacultyMarkAttendanceScreen()),
          if (isFaculty || isAdmin) item(Icons.group_add, 'Admin Portal', const AdminPortalScreen()),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Log Out'),
            onTap: () => _logout(context),
          ),
        ],
      ),
    );
  }
}
